import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, Sparkles, Search, Bell } from "lucide-react";
import hero1 from "@/assets/hero-1.jpg";
import hero2 from "@/assets/hero-2.jpg";
import hero3 from "@/assets/hero-3.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Bloom — Gentle habit tracking for calmer days" },
      {
        name: "description",
        content:
          "Bloom is a warm, mindful habit tracker. Build small daily rituals, track streaks, and stay consistent without the noise.",
      },
      { property: "og:title", content: "Bloom — Gentle habit tracking" },
      { property: "og:description", content: "Build small daily rituals with a calm, warm habit tracker." },
    ],
  }),
  component: Landing,
});

const SLIDES = [
  { src: hero1, headline: "The Art of Mindful Momentum", sub: "Elevate your daily discipline through a premium habit tracking experience designed for the intentional mind." },
  { src: hero2, headline: "Quiet Pages, Loud Progress", sub: "Capture the small rituals that compound into a calmer, more deliberate life." },
  { src: hero3, headline: "A Softer Kind of Discipline", sub: "Warm light, slow mornings, and habits that feel like care — not pressure." },
];

function Landing() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const reduce = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;
    const id = setInterval(() => setActive((i) => (i + 1) % SLIDES.length), 5000);
    return () => clearInterval(id);
  }, []);

  return (
    <main className="relative min-h-screen overflow-hidden bg-ink text-warm-50">
      {/* Rotating background slides */}
      <div className="absolute inset-0" aria-hidden="true">
        {SLIDES.map((s, i) => (
          <img
            key={s.src}
            src={s.src}
            alt=""
            className="absolute inset-0 h-full w-full object-cover transition-opacity duration-[1600ms] ease-in-out will-change-[opacity,transform]"
            style={{
              opacity: i === active ? 1 : 0,
              transform: i === active ? "scale(1.04)" : "scale(1)",
              transitionProperty: "opacity, transform",
              transitionDuration: "1600ms, 6000ms",
            }}
          />
        ))}
        {/* Warm overlay for text legibility */}
        <div className="absolute inset-0 bg-gradient-to-b from-ink/55 via-ink/35 to-ink/70" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/60 to-transparent" />
      </div>

      {/* Top nav */}
      <header className="relative z-20">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5 sm:px-10">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-amber-400">
                <Sparkles className="lucide h-4 w-4 text-ink" />
              </div>
              <span className="font-display text-lg font-semibold tracking-wide text-amber-400">
                RITUAL <span className="text-warm-50/80">&amp;</span> FOCUS
              </span>
            </Link>
            <div className="hidden items-center gap-6 text-sm md:flex">
              <Link to="/dashboard" className="relative text-amber-400 after:absolute after:-bottom-1.5 after:left-0 after:h-px after:w-full after:bg-amber-400">
                Dashboard
              </Link>
              <Link to="/dashboard" className="text-warm-50/80 transition-colors hover:text-warm-50">
                Habits
              </Link>
              <Link to="/dashboard" className="text-warm-50/80 transition-colors hover:text-warm-50">
                Journal
              </Link>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden items-center gap-2 rounded-full border border-warm-50/15 bg-warm-50/10 px-3 py-1.5 text-sm text-warm-50/80 backdrop-blur sm:flex">
              <Search className="lucide h-4 w-4" />
              <span className="hidden lg:inline">Search rituals…</span>
            </div>
            <button aria-label="Notifications" className="rounded-full border border-warm-50/15 bg-warm-50/10 p-2 text-warm-50/80 backdrop-blur transition-colors hover:text-warm-50">
              <Bell className="lucide h-4 w-4" />
            </button>
            <div className="h-8 w-8 rounded-full border border-warm-50/20 bg-gradient-to-br from-amber-400 to-amber-500" aria-hidden="true" />
          </div>
        </nav>
      </header>

      {/* Hero with cross-fading copy */}
      <section className="relative z-10 mx-auto flex min-h-[calc(100vh-88px)] max-w-5xl flex-col items-center justify-center px-6 pb-20 text-center">
        <span className="mb-6 inline-flex items-center gap-2 rounded-full border border-warm-50/20 bg-warm-50/10 px-3 py-1 text-xs uppercase tracking-[0.2em] text-warm-50/85 backdrop-blur">
          <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />
          Mindful, not militant
        </span>

        <div className="relative w-full">
          {SLIDES.map((s, i) => (
            <div
              key={s.headline}
              className="absolute inset-0 transition-opacity duration-[1200ms] ease-in-out"
              style={{ opacity: i === active ? 1 : 0, pointerEvents: i === active ? "auto" : "none" }}
              aria-hidden={i !== active}
            >
              <h1 className="font-display text-5xl leading-[1.05] tracking-tight text-warm-50 drop-shadow-[0_2px_24px_rgba(0,0,0,0.45)] sm:text-6xl lg:text-7xl">
                {s.headline}
              </h1>
              <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-warm-50/85 sm:text-lg">
                {s.sub}
              </p>
            </div>
          ))}
          {/* Spacer to give the absolutely-positioned slides height */}
          <div className="invisible">
            <h1 className="font-display text-5xl leading-[1.05] sm:text-6xl lg:text-7xl">
              The Art of Mindful Momentum
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed sm:text-lg">
              Elevate your daily discipline through a premium habit tracking experience designed for the intentional mind.
            </p>
          </div>
        </div>

        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <Link
            to="/dashboard"
            className="group inline-flex items-center gap-2 rounded-full bg-amber-400 px-7 py-3.5 text-sm font-semibold text-ink shadow-amber transition-transform hover:-translate-y-0.5"
          >
            Start Your Journey
            <ArrowRight className="lucide h-4 w-4 transition-transform group-hover:translate-x-0.5" />
          </Link>
          <Link
            to="/dashboard"
            className="rounded-full border border-warm-50/30 bg-warm-50/5 px-7 py-3.5 text-sm font-medium text-warm-50 backdrop-blur transition-colors hover:bg-warm-50/10"
          >
            Explore Method
          </Link>
        </div>

        {/* Slide indicator dots */}
        <div className="mt-12 flex items-center gap-2" role="tablist" aria-label="Scenes">
          {SLIDES.map((s, i) => (
            <button
              key={s.src}
              role="tab"
              aria-selected={i === active}
              aria-label={`Show scene ${i + 1}`}
              onClick={() => setActive(i)}
              className="h-1.5 rounded-full transition-all"
              style={{
                width: i === active ? 28 : 8,
                backgroundColor: i === active ? "var(--amber-400)" : "rgba(253,250,246,0.4)",
              }}
            />
          ))}
        </div>
      </section>
    </main>
  );
}
