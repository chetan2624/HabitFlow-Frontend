import { useState, type ReactNode } from "react";
import { Menu } from "lucide-react";
import { Sidebar } from "./Sidebar";

export function DashboardLayout({ children }: { children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="flex">
        <Sidebar
          collapsed={collapsed}
          onToggleCollapsed={() => setCollapsed((c) => !c)}
          mobileOpen={mobileOpen}
          onCloseMobile={() => setMobileOpen(false)}
        />
        <div className="flex min-h-screen flex-1 flex-col">
          <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-warm-200 bg-warm-50/80 px-4 backdrop-blur lg:px-8">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-expanded={mobileOpen}
              aria-label="Open navigation"
              className="rounded-full border border-warm-200 p-2 lg:hidden"
            >
              <Menu className="lucide h-5 w-5" />
            </button>
            <div className="flex-1">
              <p className="text-xs uppercase tracking-wider text-ink-soft">Saturday, May 2</p>
              <h2 className="font-display text-lg font-semibold text-ink">Good morning, friend</h2>
            </div>
          </header>
          <main className="flex-1 px-4 py-6 lg:px-8 lg:py-10">{children}</main>
        </div>
      </div>
    </div>
  );
}
