import { Link, useRouterState } from "@tanstack/react-router";
import {
  Home,
  CalendarDays,
  BarChart3,
  Sparkles,
  Settings,
  ChevronLeft,
  ChevronRight,
  X,
} from "lucide-react";
import { useEffect } from "react";

const NAV = [
  { label: "Today", to: "/dashboard", icon: Home },
  { label: "Week", to: "/dashboard", icon: CalendarDays },
  { label: "Insights", to: "/dashboard", icon: BarChart3 },
  { label: "Rituals", to: "/dashboard", icon: Sparkles },
  { label: "Settings", to: "/dashboard", icon: Settings },
] as const;

interface SidebarProps {
  collapsed: boolean;
  onToggleCollapsed: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export function Sidebar({ collapsed, onToggleCollapsed, mobileOpen, onCloseMobile }: SidebarProps) {
  const path = useRouterState({ select: (s) => s.location.pathname });

  // Escape closes drawer
  useEffect(() => {
    if (!mobileOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onCloseMobile();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [mobileOpen, onCloseMobile]);

  const widthClass = collapsed ? "lg:w-16" : "lg:w-60";

  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <button
          type="button"
          aria-label="Close navigation"
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-ink/40 backdrop-blur-sm lg:hidden"
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-60 flex-col bg-sidebar text-sidebar-foreground transition-transform duration-200 ease-out lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 ${widthClass} ${
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2 overflow-hidden">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-amber-400">
              <Sparkles className="lucide h-4 w-4 text-ink" aria-hidden="true" />
            </div>
            {!collapsed && (
              <span className="font-display text-lg font-semibold text-warm-50">Bloom</span>
            )}
          </div>
          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Close navigation"
            className="rounded-full p-1 text-warm-50 hover:bg-sidebar-accent lg:hidden"
          >
            <X className="lucide h-5 w-5" />
          </button>
        </div>

        <nav aria-label="Main navigation" className="flex-1 px-3">
          <ul className="space-y-1">
            {NAV.map((item, i) => {
              const Icon = item.icon;
              const isActive = i === 0 && path === "/dashboard";
              return (
                <li key={item.label}>
                  <Link
                    to={item.to}
                    aria-current={isActive ? "page" : undefined}
                    className={`flex items-center gap-3 rounded-full px-3 py-2 text-sm font-medium transition-colors ${
                      isActive
                        ? "bg-amber-400 text-ink"
                        : "text-warm-100 hover:bg-sidebar-accent hover:text-warm-50"
                    }`}
                  >
                    <Icon className="lucide h-5 w-5 shrink-0" aria-hidden="true" />
                    {!collapsed && <span>{item.label}</span>}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="hidden border-t border-sidebar-border p-3 lg:block">
          <button
            type="button"
            onClick={onToggleCollapsed}
            aria-expanded={!collapsed}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            className="flex w-full items-center justify-center gap-2 rounded-full border border-sidebar-border px-3 py-2 text-xs font-medium text-warm-100 hover:bg-sidebar-accent"
          >
            {collapsed ? (
              <ChevronRight className="lucide h-4 w-4" />
            ) : (
              <>
                <ChevronLeft className="lucide h-4 w-4" />
                <span>Collapse</span>
              </>
            )}
          </button>
        </div>
      </aside>
    </>
  );
}
