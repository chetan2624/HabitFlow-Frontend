import { useState } from "react";
import { Flame, Target, Sparkles, Check, Plus } from "lucide-react";
import healthy from "@/assets/healthy-habit.svg";
import yoga from "@/assets/yoga.svg";
import walking from "@/assets/walking.svg";

const HABITS = [
  { id: "meditate", label: "Meditate", emoji: "🧘" },
  { id: "walk", label: "Walk 20 min", emoji: "🚶" },
  { id: "read", label: "Read 10 pages", emoji: "📖" },
  { id: "water", label: "8 glasses of water", emoji: "💧" },
  { id: "journal", label: "Journal", emoji: "📓" },
];

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const TODAY_INDEX = 5; // Saturday

// Seeded mock completion (true = done)
const SEED: Record<string, boolean[]> = {
  meditate: [true, true, true, false, true, true, false],
  walk: [true, false, true, true, true, false, false],
  read: [false, true, true, true, false, true, false],
  water: [true, true, true, true, true, true, false],
  journal: [false, false, true, false, true, false, false],
};

export function DashboardHome() {
  const [grid, setGrid] = useState<Record<string, boolean[]>>(SEED);

  const toggle = (habitId: string, day: number) => {
    setGrid((g) => {
      const next = [...g[habitId]];
      next[day] = !next[day];
      return { ...g, [habitId]: next };
    });
  };

  const todayDone = HABITS.filter((h) => grid[h.id][TODAY_INDEX]).length;
  const completionRate = Math.round(
    (Object.values(grid).flat().filter(Boolean).length /
      (HABITS.length * DAYS.length)) *
      100
  );
  const longestStreak = 6;

  return (
    <div className="mx-auto max-w-7xl space-y-8">
      {/* Hero card */}
      <section className="grid grid-cols-12 gap-6">
        <div className="col-span-12 flex flex-col justify-between gap-6 rounded-[14px] border border-warm-200 bg-card p-6 shadow-card lg:col-span-8 lg:flex-row lg:items-center lg:p-8">
          <div className="max-w-md">
            <span className="inline-flex items-center gap-2 rounded-full bg-sage-100 px-3 py-1 text-xs font-medium text-ink">
              <span className="h-1.5 w-1.5 rounded-full bg-sage-500" aria-hidden="true" />
              On track this week
            </span>
            <h2 className="mt-3 font-display text-3xl text-ink lg:text-4xl">
              You've nurtured {todayDone} of {HABITS.length} rituals today.
            </h2>
            <p className="mt-3 text-ink-soft">
              Keep it gentle. Tap a habit below to mark it done — no pressure to be perfect.
            </p>
          </div>
          <img
            src={healthy}
            alt=""
            aria-hidden="true"
            className="h-40 w-auto self-center lg:h-48"
          />
        </div>
        <div className="col-span-12 flex flex-col gap-4 lg:col-span-4">
          <button
            type="button"
            className="group flex items-center justify-between gap-2 rounded-full bg-amber-400 px-5 py-3 text-sm font-semibold text-ink transition-shadow hover:shadow-amber"
          >
            <span className="flex items-center gap-2">
              <Plus className="lucide h-4 w-4" aria-hidden="true" />
              Add a new ritual
            </span>
          </button>
          <div className="flex flex-1 items-center gap-4 rounded-[14px] border border-warm-200 bg-card p-5">
            <img src={yoga} alt="" aria-hidden="true" className="h-20 w-auto" />
            <div>
              <p className="font-display text-lg text-ink">Daily intention</p>
              <p className="text-sm text-ink-soft">"Slow is smooth, smooth is steady."</p>
            </div>
          </div>
        </div>
      </section>

      {/* Stat cards */}
      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard
          icon={<Flame className="lucide h-5 w-5 text-amber-500" aria-hidden="true" />}
          label="Longest streak"
          value={`${longestStreak} days`}
          hint="Walking, this week"
        />
        <StatCard
          icon={<Target className="lucide h-5 w-5 text-sage-500" aria-hidden="true" />}
          label="Weekly completion"
          value={`${completionRate}%`}
          hint={`${Object.values(grid).flat().filter(Boolean).length} of ${HABITS.length * DAYS.length} cells`}
        />
        <StatCard
          icon={<Sparkles className="lucide h-5 w-5 text-amber-500" aria-hidden="true" />}
          label="Today's progress"
          value={`${todayDone}/${HABITS.length}`}
          hint="Habits completed"
        />
      </section>

      {/* Habit chips */}
      <section>
        <h3 className="mb-3 font-display text-xl text-ink">Today's habits</h3>
        <div className="flex flex-wrap gap-2">
          {HABITS.map((h) => {
            const done = grid[h.id][TODAY_INDEX];
            return (
              <button
                key={h.id}
                type="button"
                onClick={() => toggle(h.id, TODAY_INDEX)}
                aria-pressed={done}
                aria-label={`${h.label} — ${done ? "completed" : "not completed"} today`}
                className={`inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
                  done
                    ? "border-sage-500 bg-sage-100 text-ink"
                    : "border-warm-200 bg-warm-100 text-ink-soft hover:border-amber-400"
                }`}
              >
                <span aria-hidden="true">{h.emoji}</span>
                <span>{h.label}</span>
                {done && <Check className="lucide h-4 w-4 text-sage-500" aria-hidden="true" />}
              </button>
            );
          })}
        </div>
      </section>

      {/* Tracker grid */}
      <section className="rounded-[14px] border border-warm-200 bg-card p-5 shadow-card lg:p-6">
        <div className="mb-4 flex items-end justify-between gap-4">
          <div>
            <h3 className="font-display text-xl text-ink">This week</h3>
            <p className="text-sm text-ink-soft">Tap any cell to toggle. Today is highlighted.</p>
          </div>
          <img src={walking} alt="" aria-hidden="true" className="hidden h-20 w-auto sm:block" />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] border-separate border-spacing-1">
            <thead>
              <tr>
                <th scope="col" className="w-40 text-left text-xs font-medium uppercase tracking-wider text-ink-soft">
                  Habit
                </th>
                {DAYS.map((d, i) => (
                  <th
                    key={d}
                    scope="col"
                    className={`text-center text-xs font-medium uppercase tracking-wider ${
                      i === TODAY_INDEX ? "text-ink" : "text-ink-soft"
                    }`}
                  >
                    {d}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {HABITS.map((h) => (
                <tr key={h.id}>
                  <th scope="row" className="py-2 pr-3 text-left text-sm font-medium text-ink">
                    <span className="mr-2" aria-hidden="true">
                      {h.emoji}
                    </span>
                    {h.label}
                  </th>
                  {DAYS.map((d, i) => {
                    const done = grid[h.id][i];
                    const isToday = i === TODAY_INDEX;
                    return (
                      <td key={d} className="text-center">
                        <button
                          type="button"
                          onClick={() => toggle(h.id, i)}
                          aria-label={`${h.label}, ${d} — ${done ? "completed" : "not completed"}`}
                          aria-pressed={done}
                          className={`mx-auto flex h-10 w-10 items-center justify-center rounded-md border transition-colors ${
                            isToday ? "border-amber-400" : "border-warm-200"
                          } ${
                            done
                              ? "bg-sage-500 text-warm-50"
                              : "bg-warm-100 text-ink-soft hover:bg-warm-200"
                          }`}
                        >
                          {done ? (
                            <Check className="lucide h-4 w-4" aria-hidden="true" />
                          ) : (
                            <span className="sr-only">empty</span>
                          )}
                        </button>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  hint,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint: string;
}) {
  return (
    <div className="rounded-[14px] border border-warm-200 bg-card p-5 shadow-card">
      <div className="flex items-center gap-2">
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-warm-100">
          {icon}
        </div>
        <p className="text-sm font-medium text-ink-soft">{label}</p>
      </div>
      <p className="mt-3 font-display text-3xl text-ink">{value}</p>
      <p className="mt-1 text-xs text-ink-soft">{hint}</p>
    </div>
  );
}
